-- Die Hütte: einmal im Supabase SQL-Editor ausführen (Run)
create table if not exists public.huette_kv (
  path       text primary key,
  value      jsonb,
  updated_at timestamptz not null default now()
);

alter table public.huette_kv enable row level security;
alter table public.huette_kv replica identity full;

grant select, insert, update, delete on public.huette_kv to anon;

drop policy if exists "huette lesen"      on public.huette_kv;
drop policy if exists "huette einfuegen"  on public.huette_kv;
drop policy if exists "huette aendern"    on public.huette_kv;
drop policy if exists "huette loeschen"   on public.huette_kv;

create policy "huette lesen"     on public.huette_kv for select to anon using (true);
create policy "huette einfuegen" on public.huette_kv for insert to anon with check (true);
create policy "huette aendern"   on public.huette_kv for update to anon using (true) with check (true);
create policy "huette loeschen"  on public.huette_kv for delete to anon using (true);

-- Realtime einschalten (Fehler "already member" ist harmlos)
alter publication supabase_realtime add table public.huette_kv;
